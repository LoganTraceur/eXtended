/* ============================================================================================
// Popup/Options page script for Nimblex eXtended
// Loaded in About.html — handles DOM manipulation, table management, and settings
// Requires shared.js to be loaded first
// ============================================================================================ */

var systemsTable;

// -------------------------------------------- INITIALIZATION -----------------------------------------
document.addEventListener('DOMContentLoaded', async function () {
	await migrateFromLocalStorage();
	await initateCode();
});

// One-time migration from localStorage to chrome.storage.local (for users upgrading from MV2)
async function migrateFromLocalStorage() {
	try {
		const existing = localStorage.getItem("localData");
		if (existing) {
			await chrome.storage.local.set({ "localData": existing });
			localStorage.removeItem("localData");
			console.log("Migrated favorites from localStorage to chrome.storage.local");
		}
	} catch (error) {
		// localStorage may not be available in some contexts — that's fine
	}
}

async function initateCode() {
	await getFavouritesFromStorage();

	// Setup table
	systemsTable = document.getElementById("systemsTable");
	if (systemsTable) {
		systemsTable.addEventListener('change', onTableChange);
		await populateTable();
	}

	// Add permissions button
	try {
		document.getElementById("allowNotificationsBtn").addEventListener("click", requestNotificationPermission);
		if (Notification.permission === 'granted') {
			document.getElementById("allowNotificationsDiv").style.display = "none";		// Hide button
		}
	} catch (error) { }

	// Add change shortcuts button
	try {
		if (document.URL.toLowerCase().startsWith("chrome")) {
			// If browser = chrome show this button and attach listener
			document.getElementById("chomeShortcutsBtn").addEventListener("click", function () {
				chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
					var creating = chrome.tabs.create({
						url: "chrome://extensions/shortcuts",
						pinned: false,
						active: true,
						openerTabId: tabs[0].id,
						index: tabs[0].index + 1
					});
				});
			});
		} else {
			// If not chrome hide button
			document.getElementById("customiseShotcutsDiv").style.display = "none";
		}
	} catch (error) { }
}

// -------------------------------------------- TABLE FUNCTIONS -----------------------------------------
async function onTableChange() {
	formatOneFreeRow();
	await save_options();
}

function addNewTableRow() {
	if (systemsTable) {
		var newRow = systemsTable.insertRow(systemsTable.rows.length);
		newRow.innerHTML = `<td style="width:80px">System</td><td><input type="text" name="SystemBaseURL" style="width:250px"></td><td><input type="text" name="SystemName" style="width:150px"></td>`;
	}
}

async function populateTable() {
	await getFavouritesFromStorage();
	for (var i = 0; i < systemsObjArr.length; i++) {
		addNewTableRow();
		var myrow = systemsTable.getElementsByTagName("tr")[i + 1];
		var myUrl = myrow.getElementsByTagName("input")[0];
		var myName = myrow.getElementsByTagName("input")[1];

		myUrl.value = systemsObjArr[i].InstanceURL;
		myName.value = systemsObjArr[i].name;

		if (systemsObjArr[i].isValid) {
			myUrl.setCustomValidity("");
		} else {
			myUrl.setCustomValidity("URL Invalid. Navigate to any record in your system and paste the url here");
		}
	}

	formatOneFreeRow();
}

function formatOneFreeRow() {
	if (systemsTable) {
		for (var i = 1; i < systemsTable.rows.length; i++) {
			var myrow = systemsTable.getElementsByTagName("tr")[i];
			var myUrl = myrow.getElementsByTagName("input")[0];
			var myName = myrow.getElementsByTagName("input")[1];

			if (myName.value.length + myUrl.value.length == 0) {
				systemsTable.deleteRow(i);
				i = i - 1;
			}
		}
	}

	addNewTableRow();
}

// -------------------------------------------- SAVED USER PREFERENCES -----------------------------------------
async function save_options() {
	var newsystemsObjArr = new Array();
	for (var i = 1; i < systemsTable.rows.length; i++) {
		var myrow = systemsTable.getElementsByTagName("tr")[i];
		var myUrl = myrow.getElementsByTagName("input")[0];
		var myName = myrow.getElementsByTagName("input")[1];

		if (myName.value.length + myUrl.value.length > 0) {
			var isValidationPassed = (instanceErrorStr !== getInstanceName(getInstanceUrl(myUrl.value))
				&& isValidURL(myUrl.value))
			if (isValidationPassed) {
				// Auto populate system nickname
				if (myName.value.length == 0) {
					myName.value = getInstanceName(getInstanceUrl(myUrl.value));
				}
			}

			newsystemsObjArr.push({
				InstanceURL: getInstanceUrl(myUrl.value),
				name: myName.value,
				isValid: isValidationPassed
			});

			console.log('Option Saved: ' + myName.value + "\t" + myUrl.value);
			document.getElementById('status').textContent = i + ' Favourites Saved';
			setTimeout(function () {
				document.getElementById('status').textContent = '';
			}, 1000);
		}
	}

	await chrome.storage.local.set({ "localData": JSON.stringify(newsystemsObjArr) });
	await getFavouritesFromStorage();

	await populateTable();

	// Notify the service worker that favourites have been updated
	try {
		chrome.runtime.sendMessage({ type: "favourites-updated" });
	} catch (error) { }
}

async function DeleteData() {
	await chrome.storage.local.remove("localData");
}

// -------------------------------------------- NOTIFICATIONS -----------------------------------------
function requestNotificationPermission() {
	// Let's check if the browser supports notifications
	if (!("Notification" in window)) {
		console.log("This browser does not support desktop notification");
	}

	// Let's check whether notification permissions have already been granted
	else if (Notification.permission === "granted") {
		var notification = new Notification("Notifications are already on!");
	}

	// Otherwise, we need to ask the user for permission
	else if (Notification.permission !== 'denied' || Notification.permission === "default") {
		Notification.requestPermission(function (permission) {
			if (permission === "granted") {
				document.getElementById("allowNotificationsDiv").style.display = "none";

				chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
					var notificationObj = new Notification("Notifications Activated!", {
						icon: chrome.runtime.getURL("icons/icon-ex-48.png"),
						body: "All done. Now you will receive useful notification here." + "\nConfiguration just got better!"
					});

					notificationObj.onclick = function () {
						notificationObj.close();
						notificationObj = undefined;
					}
				});

				try {
					chrome.contextMenus.remove("enable-notifications");
					chrome.contextMenus.remove("separator_enable-notifications");
				} catch (error) { }
			}
		});
	}
}

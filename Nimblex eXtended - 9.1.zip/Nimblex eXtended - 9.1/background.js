/* ============================================================================================
// Nimblex eXtended — Service Worker (Manifest V3)
// Designed by Logan Krantz
// Date Created 2020-06-14
//
// This extension was designed by Logan Krantz and allows you to rapidly
// perform common Nimblex tasks using right click and keyboard shortcuts.
FEATURES
- Keyboard shortcuts
- "Login to All" Client System
- Log Use in Nimblex
- Works on Record view, Tabular view, Designer view, Manage Mail Merge Templates, View Revisions
- Shortcut to Eforms and Control Panel
- Quick Cluster Login
- Works on Chrome or Firefox
- Works on Nimblex 5 and 6
- Save your favourite systems,
- For favourited systems
  - Auto name based on instance.
  - Auto validate url
// ============================================================================================ */

// Load shared utilities (must be synchronous at top level)
importScripts('shared.js');

// -------------------------------------------- GLOBAL VARIABLES -----------------------------------------
var systemsVisitedStrArr = [];
var arrayOfNotificationIds = [];			// Track notification IDs (strings) for closing
var pendingNotificationActions = {};		// Map notifId -> action info for click handling
var notificationOfferClusterLoginId = null;	// Current cluster login notification ID

// -------------------------------------------- SERVICE WORKER INITIALIZATION -----------------------------------------
async function initServiceWorker() {
	await getFavouritesFromStorage();
	await restoreSessionState();
	await updateContextMenu(undefined, "On Service Worker Start");
}
initServiceWorker();

// -------------------------------------------- SESSION STATE PERSISTENCE -----------------------------------------
async function saveSessionState() {
	await chrome.storage.session.set({
		systemsVisitedStrArr: systemsVisitedStrArr,
		pendingNotificationActions: pendingNotificationActions
	});
}

async function restoreSessionState() {
	try {
		const result = await chrome.storage.session.get([
			"systemsVisitedStrArr",
			"pendingNotificationActions"
		]);
		systemsVisitedStrArr = result.systemsVisitedStrArr || [];
		pendingNotificationActions = result.pendingNotificationActions || {};
	} catch (error) {
		// chrome.storage.session may not be available in older Chrome versions
	}
}

// -------------------------------------------- LOAD OPTIONS -----------------------------------------
chrome.runtime.onInstalled.addListener(function () {
	// Open about tab after extension is installed
	chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
		var creating = chrome.tabs.create({
			url: "About.html",
			pinned: false,
			active: true,
			openerTabId: tabs[0].id,
			index: tabs[0].index + 1
		})
	});
});

// -------------------------------------------- SET UP LISTENERS -----------------------------------------
// All event listeners registered at top level (required for MV3 service workers)

// Action Context Menus click
chrome.contextMenus.onClicked.addListener((info, tab) => {
	processCommand(tab, info.menuItemId, "From Context Menu");
});

// Action Keyboard Shortcut click
chrome.commands.onCommand.addListener((command) => {
	console.log("Process keyboard shortcut: " + command);
	chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
		processCommand(tabs[0], command, "From Keyboard");
	});
});

// Listen for changes to URL's
// 1. ON URL CHANGED
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tabInfo) => {
	console.log("ON URL CHANGED");
	if (changeInfo.url) {
		chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
			if (tabInfo.id == tabs[0].id) {
				onTabChangeOrUrlUpdate(tabs[0]);
			}
		});
	}
});

// 2. ON TAB CHANGED
chrome.tabs.onActivated.addListener((info) => {
	console.log("ON TAB CHANGED");
	try {
		chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
			onTabChangeOrUrlUpdate(tabs[0]);
		});
	} catch (error) { }
});

// The injected right click listener has returned a message
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message && message.type === "favourites-updated") {
		// Popup saved new favourites — refresh context menus
		(async () => {
			await getFavouritesFromStorage();
			await updateContextMenu(undefined, "On Saved Favourites from Popup");
		})();
		return;
	}

	// Right-click refresh message from InjectRightClickListener.js
	if (sender && sender.tab) {
		updateContextMenu(sender.tab, "On Injected Right Click - " + sender.tab.url);
	}
});

// Notification click handler (replaces per-notification .onclick)
chrome.notifications.onClicked.addListener((notifId) => {
	const action = pendingNotificationActions[notifId];
	if (action) {
		if (action.action === "openAbout") {
			chrome.tabs.create({ url: "About.html" });
		} else if (action.action === "clusterLogin" && action.tabId) {
			chrome.tabs.get(action.tabId, (tab) => {
				if (chrome.runtime.lastError) return;
				if (tab) processCommand(tab, "Cluster-Login", "From Cluster Login Notification");
			});
		}
		chrome.notifications.clear(notifId);
		delete pendingNotificationActions[notifId];
		saveSessionState();
	} else {
		// Default: just close the notification
		chrome.notifications.clear(notifId);
	}
});

// This method should fire anytime the active tab changes or url changes
function onTabChangeOrUrlUpdate(tab) {
	updateContextMenu(tab, "On TAB Changed - " + tab.url);
	closeOldNotifications(tab.id);
}

// -------------------------------------------- MAJOR FUNCTIONS -----------------------------------------
async function processCommand(currentTab, command, commandFromStr) {
	var fullUrl = new URL(currentTab.url);
	var fullUrlStr = fullUrl.href;
	var InstanceURL = getInstanceUrl(fullUrlStr);
	var formName = getFormName(currentTab);
	var excludingBaseUrl = fullUrl.toString().substring(InstanceURL.length);

	switch (command) {
		case "Nimblex-eXtended":
			console.log("This is the parent level and cannot be used");
			break;
		case "Open-New":
			console.log(commandFromStr + ": Open-New: " + formName);
			if (isNimblexSix(fullUrl)) {
				var newSuffix = formName.length > 0 ? "/new" : "";
				openInDomain(InstanceURL, "/records/", formName, newSuffix);
			} else {
				openInDomain(InstanceURL, "/EFormRecord.aspx?EFormType=", formName);
			}
			break;
		case "Open-Tabular-Report":
			console.log(commandFromStr + ": Open-Tabular-Report: " + formName);
			if (isNimblexSix(fullUrl)) {
				openInDomain(InstanceURL, "/TabularReport/", formName);
			} else {
				openInDomain(InstanceURL, "/TabularReport.aspx?EFormType=", formName);
			}
			break;
		case "Open-Designer":
			console.log(commandFromStr + ": Open-Designer: " + formName);
			if (isNimblexSix(fullUrl)) {
				openInDomain(InstanceURL, "/newdesignersession/", formName);
			} else {
				openInDomain(InstanceURL, "/EFormDesigner/NewSession.aspx?EFormType=", formName);
			}
			break;
		case "Open-Mail-Merges":
			console.log(commandFromStr + ": Open-Mail-Merges: " + formName);
			if (isNimblexSix(fullUrl)) {
				openInDomain(InstanceURL, "/controlpanel/design/eforms/manage/", formName);
			} else {
				openInDomain(InstanceURL, "/ManageEForm.aspx?EFormType=", formName);
			}
			break;
		case "Open-Revisions":
			console.log(commandFromStr + ": Open-Revisions: " + formName);
			if (isNimblexSix(fullUrl)) {
				openInDomain(InstanceURL, "/controlpanel/design/eforms/revisions/", formName);
			} else {
				openInDomain(InstanceURL, "/controlpanel/EFormRevisions.aspx?EFormType=", formName);
			}
			break;
		// ------------------------------------- MISC -----------------------------------
		case "enable-notifications":
			// Navigate user to about page where they can click button.
			var creating = chrome.tabs.create({
				url: "About.html",
				pinned: false,
				active: true,
				openerTabId: currentTab.id,
				index: currentTab.index + 1
			})
			break;
		case "Cluster-Login":
			console.log(commandFromStr + ": Open-Cluster-Login");
			var clusterUrlStr = getClusterUrl(InstanceURL);
			var instanceNameStr = getInstanceName(InstanceURL);
			var jumpIntoInstanceUrlStr = getJumpIntoInstanceAdminUrl(clusterUrlStr, instanceNameStr);

			openClusterLoginWithRedirect(jumpIntoInstanceUrlStr, fullUrlStr, false, currentTab);
			break;
		case "Open-Eforms":
			console.log(commandFromStr + ": Open-Eforms");
			if (isNimblexSix(fullUrl)) {
				openURL(InstanceURL + "/eforms");
			} else {
				openURL(InstanceURL + "/EForms.aspx");
			}
			break;
		case "Open-ControlPanel":
			console.log(commandFromStr + ": Open-ControlPanel");
			if (isNimblexSix(fullUrl)) {
				openURL(InstanceURL + "/controlpanel");
			} else {
				openURL(InstanceURL + "/ControlPanel/Default.aspx");
			}
			break;
		case "Open-ReevaluateRecords":
			console.log(commandFromStr + ": Open-ReevaluateRecords");
			openURL(InstanceURL + "/controlpanel/records/updaterecords");
			break;
		case "About":
			var creating = chrome.tabs.create({
				url: "About.html",
				pinned: false,
				active: true,
				openerTabId: currentTab.id,
				index: currentTab.index + 1
			})
			break;
		// ------------------------------------- FAVOURITE SYSTEMS -----------------------------------
		case "Add-To-Favourites":
			await getFavouritesFromStorage();
			systemsObjArr.push({
				InstanceURL: InstanceURL,
				name: getInstanceName(InstanceURL),
				isValid: true
			});

			await chrome.storage.local.set({ "localData": JSON.stringify(systemsObjArr) });
			await getFavouritesFromStorage();
			await updateContextMenu(currentTab, "On Add to Favourites - " + currentTab.url);

			var notifId = "add-fav-" + Date.now();
			chrome.notifications.create(notifId, {
				type: "basic",
				iconUrl: "icons/icon-ex-48.png",
				title: "Added to Favourites",
				message: getInstanceName(InstanceURL) + " has been added to favourites.\nHow cool is that!\nClick here to view your favourites"
			});
			pendingNotificationActions[notifId] = { action: "openAbout", tabId: currentTab.id };
			arrayOfNotificationIds.push({ notifId: notifId, tabId: currentTab.id });
			await saveSessionState();
			break;
		case "Open-In-Login-To-All":
			await getFavouritesFromStorage();
			for (i = 0; i < systemsObjArr.length; i++) {
				if (systemsObjArr[i].name.length > 0 && systemsObjArr[i].InstanceURL.length > 0) {
					var instanceUrlStr = systemsObjArr[i].InstanceURL;
					var clusterUrlStr = getClusterUrl(instanceUrlStr);
					var instanceNameStr = getInstanceName(instanceUrlStr);
					var jumpIntoInstanceUrlStr = getJumpIntoInstanceAdminUrl(clusterUrlStr, instanceNameStr);
					openURL(jumpIntoInstanceUrlStr);
				}
			}
			break;
		default:
			// Open the current page in a favourite system
			await getFavouritesFromStorage();
			if (command.substring(0, 8) == "Open-In-") {
				var systemIndex = Number(command.substring(8));
				var instanceUrlStr = systemsObjArr[systemIndex].InstanceURL;
				console.log(commandFromStr + ": command: " + command + "\tFavourite Index: " + systemIndex);

				await openInNewDomain_checkIfNimblex(currentTab, instanceUrlStr, excludingBaseUrl, formName);
			}
	}
}

// -------------------------------------------- GET FORM NAME -----------------------------------------
function getFormName(currentTab) {
	if (!currentTab || !currentTab.url) { return ""; }

	var fullUrl = new URL(currentTab.url);
	var fullUrlStr = fullUrl.toString().toLowerCase();
	var tabTitle = currentTab.title;

	var formName = "";
	if (fullUrl.searchParams.get("EFormType")) {
		// Nimblex 5.7
		formName = fullUrl.searchParams.get("EFormType");
	} else if (
		!(fullUrlStr.includes("/eforms/revisions/")
			|| fullUrlStr.includes("/eforms/manage/"))
		&& (fullUrlStr.includes("/controlpanel")
			|| fullUrlStr.includes("/eforms")
			|| fullUrlStr.includes("/myeforms")
			|| fullUrlStr.includes("/quicklinks")
			|| fullUrlStr.includes("/currentusersettings")
		)) {
		formName = "";
	} else if (
		fullUrlStr.includes("/designer/")
		|| fullUrlStr.includes("/continuerecord/")
	) {
		if (tabTitle.includes(" (")) {
			formName = tabTitle.substring(0, tabTitle.indexOf(" ("));
		} else {
			formName = tabTitle;
		}
	} else if (isNimblexSix(fullUrl)) {
		var myArray = fullUrl.pathname.split('/');
		var i = 0;
		for (i = 0; i < myArray.length; i++) {
			if (myArray[i].toLowerCase() == "records"
				|| myArray[i].toLowerCase() == "tabularreport"
				|| myArray[i].toLowerCase() == "revisions"
				|| myArray[i].toLowerCase() == "manage"
				|| myArray[i].toLowerCase() == "recorddeleted"
			) {
				formName = decodeURIComponent(myArray[i + 1]);
				break;
			}
		}
	} else {
		// Nimblex 5.7
		if (tabTitle.indexOf(" / Default") > 0) {
			formName = tabTitle.substring(5, tabTitle.indexOf(" / Default"));
		} else if (tabTitle.indexOf(" (") > 0) {
			formName = tabTitle.substring(5, tabTitle.indexOf(" ("));
		} else if (tabTitle.toLowerCase().includes(" - nimblex")) {
			formName = tabTitle.substring(0, tabTitle.indexOf(" - Nimblex"));
			if (formName.toLowerCase() == "control panel") {
				formName = "";
			}
		}
	}
	return formName;
}

// -------------------------------------------- SUPPORT FUNCTIONS -----------------------------------------
function addInstanceToHistory(instanceUrlStr) {
	if (systemsVisitedStrArr.indexOf(instanceUrlStr) === -1) {
		systemsVisitedStrArr.push(instanceUrlStr);
		saveSessionState();
	}
}

function isNimblexSix(fullUrl) {
	var fullUrlStr = fullUrl.toString().toLowerCase();
	return (fullUrlStr.includes("/records/")
		|| fullUrlStr.includes("/tabularreport/")
		|| fullUrlStr.includes("/designer/")
		|| fullUrlStr.includes("/revisions/")
		|| fullUrlStr.includes("/manage/")
		|| fullUrlStr.includes("/continuerecord/")
		|| fullUrlStr.includes("/recorddeleted/")
		|| fullUrlStr.endsWith("/eforms")
		|| fullUrlStr.endsWith("/controlpanel")
	);
}

function openInDomain(base, middle, formName, suffix) {
	var encodedFormName = formName ? encodeURIComponent(formName) : "";
	var builtURL = base + middle + encodedFormName + (suffix || "");
	if (formName) {
		openURL(builtURL);
	} else {
		console.log("Cant go to: " + builtURL);

		chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
			var notifId = "eform-error-" + Date.now();
			chrome.notifications.create(notifId, {
				type: "basic",
				iconUrl: "icons/icon-ex-48.png",
				title: "EForm name could not be found",
				message: "I sense a disturbance in the force,\nThe eform name could not be found\nMove Along...\nMove Along..."
			});
			arrayOfNotificationIds.push({ notifId: notifId, tabId: tabs[0].id });
		});
	}
}

function isUrlNonClusterLoginPage(fullUrlStr) {
	var instanceUrlStr = getInstanceUrl(fullUrlStr);
	var myResult = (fullUrlStr.startsWith(instanceUrlStr + "/login") == true
		&& fullUrlStr.includes("/admin/login") == false);
	return myResult;
}

function getUrlInNewDomain(instanceURLStr, end, formName) {
	var builtURL;
	if (formName) {
		var encodedFormName = encodeURIComponent(formName);
		if (end.toLowerCase().includes("/controlpanel/design/eforms/revisions/")) {
			builtURL = instanceURLStr + "/controlpanel/design/eforms/revisions/" + encodedFormName;
		} else if (end.toLowerCase().includes("/controlpanel/design/eforms/manage/")) {
			builtURL = instanceURLStr + "/controlpanel/design/eforms/manage/" + encodedFormName;
		} else if (end.toLowerCase().includes("/designer/")) {
			var endArray = end.split("/")
			endArray.splice(1, 2);
			gotoDesignerSubAreaStr = endArray.join("/");
			gotoDesignerSubAreaStr = gotoDesignerSubAreaStr.substring(1);
			gotoDesignerSubAreaStr = "?goto=" + gotoDesignerSubAreaStr;
			builtURL = instanceURLStr + "/newdesignersession/" + encodedFormName + gotoDesignerSubAreaStr;
		} else if (end.toLowerCase().includes("tabularreport")) {
			builtURL = instanceURLStr + "/TabularReport.aspx?EFormType=" + encodedFormName;
		} else {
			builtURL = instanceURLStr + "/EFormRecord.aspx?EFormType=" + encodedFormName;
		}
	} else {
		builtURL = instanceURLStr + end;
	}
	return builtURL;
}

function openURL(builtURL) {
	logRequestInNimblex(builtURL);

	console.log("openURL: " + builtURL);
	addInstanceToHistory(getInstanceUrl(builtURL));

	chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
		var creating = chrome.tabs.create({
			url: builtURL,
			pinned: false,
			active: true,
			openerTabId: tabs[0].id,
			index: tabs[0].index + 1
		})
	});
}

function openClusterLoginWithRedirect(jumpIntoInstanceUrlStr, originalUrl, isOpenInNewTab, currentTab) {
	var instanceURLStr = getInstanceUrl(originalUrl);

	logRequestInNimblex("Cluster login then redirect to " + originalUrl);
	addInstanceToHistory(getInstanceUrl(jumpIntoInstanceUrlStr));

	// 1. Navigate to cluster login
	if (isOpenInNewTab == true) {
		chrome.tabs.create({
			url: jumpIntoInstanceUrlStr,
			active: true,
			openerTabId: currentTab.id,
			index: currentTab.index + 1
		}, createRedirectListeners);
	} else {
		chrome.tabs.update({ url: jumpIntoInstanceUrlStr, active: true }, createRedirectListeners);
	}

	// 2. After new tab is created add listener for when cluster login is completed
	function createRedirectListeners(tab) {
		var newClusterLoginTabId = tab.id;
		chrome.tabs.onUpdated.addListener(function clusterRedirectListener(tabId, changeInfo, tab) {
			// 3. Wait until the user has logged in
			if (tabId == newClusterLoginTabId
				&& tab.status == "complete"
				&& tab.url.toLowerCase().startsWith(instanceURLStr.toLowerCase()) == true
				&& tab.url.includes("/clusterEntry/") == false
			) {
				// 4. Remove the listener
				chrome.tabs.onUpdated.removeListener(clusterRedirectListener);
				// 5. Navigate to original url
				originalUrl = originalUrl.replace("loggedOut=true", "loggedOut=false");

				chrome.tabs.update(newClusterLoginTabId, { url: originalUrl }, () => {
					if (tab.url.includes("/login?returnTo=")) {
						chrome.tabs.reload(newClusterLoginTabId);
					}
					// 6. Tell the user how great we are
					createNotificationRedirectAfterClusterLogin(newClusterLoginTabId);
				});
			}
		});
	}
}

// No longer used after beta testing completed
function logRequestInNimblex(requestMessage) {
}

// -------------------------------------------- IS_SITE_NIMBLEX_METHODS -----------------------------------------
async function openInNewDomain_checkIfNimblex(currentTab, instanceUrlStr, excludingBaseUrl, formName) {
	if (isValidTab(currentTab)) {
		try {
			const results = await chrome.scripting.executeScript({
				target: { tabId: currentTab.id },
				func: () => document.querySelector("head").innerHTML.includes("Nimblex")
			});
			var isCurrentSiteNimblexParamater = results && results[0] && results[0].result === true;
			if (isCurrentSiteNimblexParamater) {
				var urlInNewDomain = getUrlInNewDomain(instanceUrlStr, excludingBaseUrl, formName);
				openURL(urlInNewDomain);
			} else {
				openURL(instanceUrlStr);
			}
		} catch (error) {
			openURL(instanceUrlStr);
		}
	} else {
		openURL(instanceUrlStr);
	}
}

var updateContextMenuQueue = Promise.resolve();
async function updateContextMenu(currentTab, logStr) {
	updateContextMenuQueue = updateContextMenuQueue.then(() => updateContextMenuInner(currentTab, logStr)).catch(() => {});
	return updateContextMenuQueue;
}

async function updateContextMenuInner(currentTab, logStr) {
	var isValidTabResult = isValidTab(currentTab);
	if (isValidTabResult) {
		try {
			const results = await chrome.scripting.executeScript({
				target: { tabId: currentTab.id },
				func: () => document.querySelector("head").innerHTML.includes("Nimblex")
			});
			var isCurrentSiteNimblexParamater = currentTab != undefined
				&& results != undefined
				&& results[0] != undefined
				&& results[0].result === true;
			await updateContextMenuNested(currentTab, logStr, isCurrentSiteNimblexParamater, isValidTabResult);
		} catch (error) {
			await updateContextMenuNested(currentTab, logStr, false, isValidTabResult);
		}
	} else {
		var isCurrentSiteNimblexParamater = false;
		await updateContextMenuNested(currentTab, logStr, isCurrentSiteNimblexParamater, isValidTabResult);
	}
}

function isValidTab(tab) {
	var myUrl = "";
	var myPendingUrl = "";
	if (tab) {
		myUrl = tab.url || "";
		myPendingUrl = tab.pendingUrl || "";
	}

	return (tab
		&& tab
		&& tab.title != "About Nimblex eXtended"
		&& myUrl.startsWith("about:blank") == false
		&& myPendingUrl.startsWith("chrome://newtab/") == false
		&& myUrl.startsWith("chrome://newtab/") == false
		&& myUrl.startsWith("about:newtab") == false
		&& myUrl.startsWith("moz-extension://") == false
		&& myPendingUrl.startsWith("moz-extension://") == false
		&& myUrl.startsWith("chrome://extensions") == false
		&& myUrl.startsWith("chrome-extension://") == false
		&& myPendingUrl.startsWith("chrome://extensions") == false
		&& myPendingUrl.startsWith("chrome-extension://") == false
	);
}

// -------------------------------------------- CONTEXT MENUS -----------------------------------------
async function updateContextMenuNested(currentTab, logStr, isCurrentSiteNimblexParamater, isValidTabResult) {
	// ________________________________________________________________________________________________
	// 1. Prep Work
	var fullUrlStr;
	if (currentTab && currentTab.url) {
		fullUrlStr = currentTab.url.toLowerCase();
	} else {
		fullUrlStr = "";
	}

	// ________________________________________________________________________________________________
	// 2. Remove all context menus to start fresh
	await new Promise((resolve) => chrome.contextMenus.removeAll(resolve));

	// ________________________________________________________________________________________________
	// 3. Perform all tests
	var isCurrentSiteNimblex = isCurrentSiteNimblexParamater;
	var isClusterLoginVisible = (isCurrentSiteNimblex == true && isUrlNonClusterLoginPage(fullUrlStr));
	var isAddToFavouritesVisible = (isCurrentSiteNimblex == true
		&& getInstanceUrl(fullUrlStr).length > 0
		&& getInstanceName(getInstanceUrl(fullUrlStr)).length > 0
		&& isSystemAlreadyFavourite(fullUrlStr) == false);
	var isFavouriteSystemsVisible = (await countOfValidFavourites() > 0);
	var isEformNameFound = isCurrentSiteNimblex && (getFormName(currentTab).length > 0);
	var isGeneralFunctionsVisible = isCurrentSiteNimblex == true
		&& isClusterLoginVisible == false
		&& fullUrlStr.includes("/admin/login") == false
		&& fullUrlStr.includes("/admin/instances/enter/") == false;

	var isQuickFavourite = isCurrentSiteNimblex == false
		&& isFavouriteSystemsVisible == true;

	// ________________________________________________________________________________________________
	// 4. Create Context Menu including hidden items
	var topMenuTitle;
	var favouriteMenuParentID;
	if (isQuickFavourite) {
		topMenuTitle = "Nimblex eXtended - My Favourites";
		favouriteMenuParentID = "Nimblex-eXtended";
	} else {
		topMenuTitle = "Nimblex eXtended";
		favouriteMenuParentID = "Open-In";
	}

	// MENU HEADING: "Nimblex Extended"
	chrome.contextMenus.create({
		id: "Nimblex-eXtended",
		title: topMenuTitle
	});

	// MENU ITEM: "Cluster Login"
	if (isClusterLoginVisible) {
		chrome.contextMenus.create({
			parentId: "Nimblex-eXtended",
			id: "Cluster-Login",
			title: "Jump to Cluster Login",
			visible: isClusterLoginVisible
		});
		chrome.contextMenus.create({ parentId: "Nimblex-eXtended", type: "separator", id: "separator_Cluster-Login" });
	}

	// Notify the user that they can jump to cluster login
	createNotificationOfferClusterLogin(isClusterLoginVisible, currentTab, fullUrlStr);

	// MENU ITEM: "Add to Favourites"
	if (isAddToFavouritesVisible) {
		chrome.contextMenus.create({
			parentId: "Nimblex-eXtended",
			id: "Add-To-Favourites",
			title: "Add to Favourites",
			visible: isAddToFavouritesVisible
		});
		chrome.contextMenus.create({ parentId: "Nimblex-eXtended", type: "separator", id: "separator_Add-To-Favourites" });
	}

	// MENU SUB-HEADING: "My Favourites"
	if (isFavouriteSystemsVisible && isQuickFavourite == false) {
		chrome.contextMenus.create({
			parentId: "Nimblex-eXtended",
			id: "Open-In",
			title: "My Favourites",
			visible: isFavouriteSystemsVisible
		});
		chrome.contextMenus.create({ parentId: "Nimblex-eXtended", type: "separator", id: "separator_My-Favourites" });
	}

	// MENU ITEMS: "New, Tabular Report, Designer, Mail Merges"
	if (isEformNameFound) {
		chrome.contextMenus.create({
			parentId: "Nimblex-eXtended",
			id: "Open-New",
			title: "Open N\u0332ew Record",
			visible: isEformNameFound
		});

		chrome.contextMenus.create({
			parentId: "Nimblex-eXtended",
			id: "Open-Tabular-Report",
			title: "Open Tabular R\u0332eport",
			visible: isEformNameFound
		});

		chrome.contextMenus.create({
			parentId: "Nimblex-eXtended",
			id: "Open-Designer",
			title: "Open C\u0332ustom Designer",
			visible: isEformNameFound
		});

		chrome.contextMenus.create({
			parentId: "Nimblex-eXtended",
			id: "Open-Mail-Merges",
			title: "Open Mail Merges",
			visible: isEformNameFound
		});

		chrome.contextMenus.create({
			parentId: "Nimblex-eXtended",
			id: "Open-Revisions",
			title: "Open Revisions",
			visible: isEformNameFound
		});
		chrome.contextMenus.create({ parentId: "Nimblex-eXtended", type: "separator", id: "separator_eformControls" });
	}

	// MENU ITEMS: "Eforms List, Control Panel"
	if (isGeneralFunctionsVisible) {
		chrome.contextMenus.create({
			parentId: "Nimblex-eXtended",
			id: "Open-Eforms",
			title: "Open EForms L\u0332ist",
			visible: isGeneralFunctionsVisible
		});

		chrome.contextMenus.create({
			parentId: "Nimblex-eXtended",
			id: "Open-ControlPanel",
			title: "Open Control Panel",
			visible: isGeneralFunctionsVisible
		});

		chrome.contextMenus.create({
			parentId: "Nimblex-eXtended",
			id: "Open-ReevaluateRecords",
			title: "Open Re-evaluate Records",
			visible: isGeneralFunctionsVisible
		});
		chrome.contextMenus.create({ parentId: "Nimblex-eXtended", type: "separator", id: "separator_GeneralControls" });
	}

	// ________________________________________________________________________________________________
	// 5. Dynamically create the "My Favourites" sub menu
	var favouriteMenuItemsCreatedCount = 0;
	for (var j = 0; j < systemsObjArr.length; j++) {
		var newIDStr = "Open-In-" + j;
		chrome.contextMenus.create({
			parentId: favouriteMenuParentID,
			id: newIDStr,
			title: systemsObjArr[j].name,
			visible: systemsObjArr[j].isValid
		});
		favouriteMenuItemsCreatedCount = j + 1;
	}

	if (isFavouriteSystemsVisible) {
		chrome.contextMenus.create({
			parentId: favouriteMenuParentID,
			id: "Open-In-Login-To-All",
			title: "Login to All",
			visible: isFavouriteSystemsVisible
		});
	}

	if (isQuickFavourite) {
		chrome.contextMenus.create({ parentId: "Nimblex-eXtended", type: "separator", id: "separator_isQuickFavourite" });
	}

	// ________________________________________________________________________________________________
	// 6. Add the last menu item
	chrome.contextMenus.create({
		parentId: "Nimblex-eXtended",
		id: "About",
		title: "About Nimblex eXtended"
	});

	// ________________________________________________________________________________________________
	// COMPLETED
	let reportObject = new Object();
	reportObject.A_LogString = logStr;
	reportObject.B_isValidTabResult = isValidTabResult;
	reportObject.C_isCurrentSiteNimblex = isCurrentSiteNimblex;
	reportObject.D_isClusterLoginVisible = isClusterLoginVisible;
	reportObject.E_isQuickFavourite = isQuickFavourite;
	reportObject.F_isAddToFavouritesVisible = isAddToFavouritesVisible;
	reportObject.G_isFavouriteSystemsVisible = "" + isFavouriteSystemsVisible + ": " + favouriteMenuItemsCreatedCount + " favourites";
	reportObject.H_isEformNameFound = isEformNameFound;
	reportObject.I_isGeneralFunctionsVisible = isGeneralFunctionsVisible;
	reportObject.J_fullUrlStr = fullUrlStr;
	reportObject.J_instanceURL = getInstanceUrl(fullUrlStr);
}

// -------------------------------------------- NOTIFICATIONS -----------------------------------------
function closeOldNotifications(currentTabId) {
	for (var i = arrayOfNotificationIds.length - 1; i >= 0; i--) {
		try {
			if (arrayOfNotificationIds[i].tabId != currentTabId) {
				chrome.notifications.clear(arrayOfNotificationIds[i].notifId);
				delete pendingNotificationActions[arrayOfNotificationIds[i].notifId];
				arrayOfNotificationIds.splice(i, 1);
			}
		} catch (error) {
			console.log("Error Removing Notification");
		}
	}
}

// Notify the user that they have the OPTION to jump to cluster login
function createNotificationOfferClusterLogin(isClusterLoginVisible, currentTab, fullUrlStr) {
	if (isClusterLoginVisible
		&& fullUrlStr.startsWith("https://ebms.com.au/dev/ebms/login") == false
	) {
		// Clear previous cluster login notification if exists
		if (notificationOfferClusterLoginId) {
			chrome.notifications.clear(notificationOfferClusterLoginId);
			delete pendingNotificationActions[notificationOfferClusterLoginId];
		}

		notificationOfferClusterLoginId = "cluster-login-" + Date.now();
		chrome.notifications.create(notificationOfferClusterLoginId, {
			type: "basic",
			iconUrl: "icons/icon-ex-48.png",
			title: "Did you want the Cluster Login page?",
			message: "All you need to do is click here or right click and select the option from the Nimblex eXtended menu.\nNo need to thank us!"
		});

		pendingNotificationActions[notificationOfferClusterLoginId] = {
			action: "clusterLogin",
			tabId: currentTab.id
		};
		arrayOfNotificationIds.push({ notifId: notificationOfferClusterLoginId, tabId: currentTab.id });
		saveSessionState();
	} else {
		// Remove notification
		if (notificationOfferClusterLoginId) {
			try {
				chrome.notifications.clear(notificationOfferClusterLoginId);
				delete pendingNotificationActions[notificationOfferClusterLoginId];
				notificationOfferClusterLoginId = null;
			} catch (error) { }
		}
	}
}

// Notify the user that we redirected them after a cluster login.
function createNotificationRedirectAfterClusterLogin(tabId) {
	var notifId = "redirect-" + Date.now();
	chrome.notifications.create(notifId, {
		type: "basic",
		iconUrl: "icons/icon-ex-48.png",
		title: "\u266B What can I say except You're Welcome \u266B",
		message: "We just navigated you here after you used the cluster log in.\nHey its ok, its ok, You're Welcome!"
	});
	arrayOfNotificationIds.push({ notifId: notifId, tabId: tabId });
}

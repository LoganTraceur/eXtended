/* ============================================================================================
// Shared utilities for Nimblex eXtended
// Used by both the service worker (background.js) and the popup (popup.js)
// ============================================================================================ */

// -------------------------------------------- GLOBAL VARIABLES -----------------------------------------
const instanceErrorStr = "{Provide Instance}";
var systemsObjArr = [];

// -------------------------------------------- STORAGE -----------------------------------------
async function getFavouritesFromStorage() {
	const result = await chrome.storage.local.get("localData");
	if (result.localData != null) {
		systemsObjArr = JSON.parse(result.localData);
	}
}

// -------------------------------------------- USEFUL FUNCTIONS -----------------------------------------
async function countOfValidFavourites() {
	await getFavouritesFromStorage();		// Refresh system data from saved data
	var count = 0;
	for (var i = 0; i < systemsObjArr.length; i++) {
		if (systemsObjArr[i].isValid) {
			count = count + 1;
		}
	}
	return count;
}

// -------------------------------------------- CLUSTER & INSTANCE FUNCTIONS -----------------------------------------
// Return TRUE if string is often found after the Instance in a Nimblex URL
function isAfterInstance(UrlSubstring) {
	// here are the common phrases that appear after the instance in a Nimblex URL
	UrlSubstring = UrlSubstring.toLowerCase();
	return (UrlSubstring.includes("aspx")				// Most of Nimblex 5.7
		|| UrlSubstring == "records"					// Nimblex 6 Specific
		|| UrlSubstring == "tabularreport"				// Nimblex 6 Specific
		|| UrlSubstring == "calendarreport"				// Nimblex 6 Specific
		|| UrlSubstring == "chartingreport"				// Nimblex 6 Specific
		|| UrlSubstring == "controlpanel"				// Nimblex 6 and 5.7
		|| UrlSubstring == "designer"					// Nimblex 6 Specific this includes revisions
		|| UrlSubstring == "quicklinks"					// Nimblex 6 Specific
		|| UrlSubstring == "myprofile"					// Nimblex 6 Specific
		|| UrlSubstring == "eula"						// Nimblex 6 Specific
		|| UrlSubstring == "continuerecord"				// Nimblex 6 Specific
		|| UrlSubstring == "recorddeleted"				// Nimblex 6 Specific
		|| UrlSubstring == "login"						// URL is to login screen
		|| UrlSubstring.includes("login?returnto=")		// URL is to login screen with redirect

		// Not sure if these ones are required. But kept anyway
		|| UrlSubstring.includes("eformdesigner")
		|| UrlSubstring.includes("controlpanel")
		|| UrlSubstring.includes("eforms")				// Do not include eforms page in Instance url
	);
}

// Returns the Cluster and Instance URL. This is the most useful URL.
function getInstanceUrl(fullUrlStr) {
	var buildingInstanceUrl = "";
	var myArray = fullUrlStr.split('/');
	if (fullUrlStr.toLowerCase().includes("/admin/instances/enter/")) {
		// N6 Jump into instance URL: "/admin/instances/enter/"
		buildingInstanceUrl = fullUrlStr.replace(/\/admin\/instances\/enter\//i, "/");
	} else if (fullUrlStr.toLowerCase().includes("/admin/jumpintoinstance.aspx?instancename=")) {
		// N5 Jump into instance URL: "/JumpIntoInstance.aspx?InstanceName="
		buildingInstanceUrl = fullUrlStr.replace(/\/admin\/JumpIntoInstance.aspx\?InstanceName=/i, "/");
	} else if (decodeURIComponent(fullUrlStr).toLowerCase().includes("/admin/login.aspx?returnurl=~/admin/jumpintoinstance.aspx?instancename=")) {
		// N5 Jump into instance URL: "/Admin/Login.aspx?ReturnUrl=~/Admin/JumpIntoInstance.aspx?InstanceName="
		fullUrlStr = decodeURIComponent(fullUrlStr);
		buildingInstanceUrl = fullUrlStr.replace(/\/Admin\/Login.aspx\?ReturnUrl=~\/Admin\/JumpIntoInstance.aspx\?InstanceName=/i, "/");
	} else if (decodeURIComponent(fullUrlStr).toLowerCase().includes("/admin/login")) {
		// N6 Jump into instance URL: "/admin/login?returnTo=/instances/enter/SGC-DEV"
		fullUrlStr = decodeURIComponent(fullUrlStr);
		buildingInstanceUrl = fullUrlStr.split("/admin/login")[0];
		buildingInstanceUrl = buildingInstanceUrl + "/" + fullUrlStr.split("/instances/enter/")[1];
	} else {
		// Try to decipher URL
		for (var i = 0; i < myArray.length; i++) {
			if (isAfterInstance(myArray[i]) == false) {
				if (myArray[i] == "") {
					// This value is empty. Do not add it to array.
				} else {
					if (i == myArray.length - 1 && myArray[i].toLowerCase() == "admin") {
						buildingInstanceUrl = buildingInstanceUrl + '/' + instanceErrorStr;
					} else {
						buildingInstanceUrl = buildingInstanceUrl + '/' + myArray[i];
					}
				}
			} else {
				break;
			}
		}
	}

	// Clean up and remove any leading '/'
	if (buildingInstanceUrl.substring(0, 1) == "/") {
		buildingInstanceUrl = buildingInstanceUrl.substring(1);
	}

	// This finds only the first ":/" (with 1 or more dashes) and converts it to the correct "://"
	if (buildingInstanceUrl.substring(0, 7) == "https:/" || buildingInstanceUrl.substring(0, 6) == "http:/") {
		buildingInstanceUrl = buildingInstanceUrl.replace(/:\/+/i, "://");
	}

	return buildingInstanceUrl;
}

// Return the Cluster URL excluding the Instance Name. Requires the Instance URL
function getClusterUrl(InstanceUrlStr) {
	var myArray = InstanceUrlStr.replace("://", "*1*2*3*").split('/');
	myArray.pop();

	if (myArray.join("/").length > 0) {
		clusterURL = myArray.join("/");
		clusterURL = clusterURL.replace("*1*2*3*", "://");
		return clusterURL;
	} else {
		return InstanceUrlStr;
	}
}

// Return the Instance Name. Requires the Instance URL
function getInstanceName(InstanceUrlStr) {
	var myArray = InstanceUrlStr.replace("://", "***").split('/');
	if (myArray.length == 1) {
		var arrayOfWords = InstanceUrlStr.replace("://", ".").split('.')
		var firstWord = arrayOfWords[1]
		return firstWord;
	} else {
		return myArray[myArray.length - 1];
	}
}

function getJumpIntoInstanceAdminUrl(clusterUrlStr, instanceNameStr) {
	if (instanceNameStr.length > 0) {
		return clusterUrlStr + "/admin/JumpIntoInstance.aspx?InstanceName=" + instanceNameStr;
	} else {
		return clusterUrlStr + "/admin";
	}
}

// -------------------------------------------- VALIDATION -----------------------------------------
// tests if String is a valid URL
function isValidURL(str) {
	var pattern = new RegExp('^(https?:\\/\\/)?' + // protocol
		'((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
		'((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
		'(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
		'(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
		'(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator
	return !!pattern.test(str);
}

function isSystemAlreadyFavourite(fullUrlStr) {
	var instanceUrlStr = getInstanceUrl(fullUrlStr);
	for (var i = 0; i < systemsObjArr.length; i++) {
		if (systemsObjArr[i].InstanceURL.toLowerCase() == instanceUrlStr) {
			return true;
		}
	}
	return false;
}

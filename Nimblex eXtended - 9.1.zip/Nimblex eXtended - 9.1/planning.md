# Nimblex eXtended: Manifest V2 → V3 Migration Plan

## Context

Chrome disabled Manifest V2 extensions starting late 2024. Nimblex eXtended v8.6 uses MV2 and no longer works in Chrome. This plan migrates it to MV3.

The core challenge: `background.js` (1434 lines) is a **hybrid file** loaded both as the persistent background page AND via `<script>` tag in `About.html`. It contains background logic, DOM manipulation, and shared utilities all mixed together. MV3 requires the background to be a **service worker** (no DOM access, can sleep and restart), so this file must be split apart.

---

## File Changes Summary

| File | Action |
|------|--------|
| `manifest.json` | Rewrite for MV3 |
| `background.js` | Rewrite — remove DOM code, migrate deprecated APIs |
| `shared.js` | **New** — shared utility functions (used by both service worker & popup) |
| `popup.js` | **New** — DOM/UI code extracted from background.js |
| `About.html` | Modify — update 2 script tags |
| `about.js` | Delete (guard variable no longer needed) |
| `InjectRightClickListener.js` | No changes needed |
| `icons/` | No changes needed |

---

## Step 1: Update `manifest.json`

| Change | Old (MV2) | New (MV3) |
|--------|-----------|-----------|
| Version | `"manifest_version": 2` | `"manifest_version": 3` |
| Background | `"background": { "scripts": ["background.js"] }` | `"background": { "service_worker": "background.js" }` |
| Browser Action | `"browser_action": { ... }` | `"action": { ... }` |
| Host Permissions | In `permissions` array | Separate `"host_permissions": ["<all_urls>"]` |
| New Permissions | — | Add `"scripting"` and `"storage"` |
| Theme Icons | `"theme_icons": [...]` | Remove (not supported in MV3 `action`) |
| Comment Keys | `"COMMENT_____..."` | Remove all |
| Firefox Settings | `"browser_specific_settings"` | Remove (Chrome-focused; re-add later) |
| Icons | Missing 128px | Add `"128": "icons/icon-ex-128.png"` |

**Best practice note**: Per [Chrome's official migration checklist](https://developer.chrome.com/docs/extensions/develop/migrate/checklist), the `service_worker` field takes a **string** (not an array). If we need to load `shared.js`, we use `importScripts()` inside the service worker file itself.

---

## Step 2: Create `shared.js` — Shared Utilities

Extract these functions from `background.js` (used by both service worker and popup):

**Constants & State:**
- `instanceErrorStr` (line 52)
- `systemsObjArr` declaration (line 53)

**URL Parsing Functions (unchanged):**
- `isAfterInstance()` (lines 454-477)
- `getInstanceUrl()` (lines 480-534)
- `getClusterUrl()` (lines 537-548)
- `getInstanceName()` (lines 551-561)
- `getJumpIntoInstanceAdminUrl()` (lines 563-570)

**Validation (unchanged):**
- `isValidURL()` (lines 867-875)
- `isSystemAlreadyFavourite()` (lines 990-998)

**Storage (MIGRATED from localStorage to chrome.storage.local):**
- `getFavouritesFromStorage()` (lines 934-941) — becomes **async**
- `countOfValidFavourites()` (lines 128-138) — becomes **async** (calls getFavouritesFromStorage)

### Key migration:
```javascript
// OLD (localStorage — synchronous, not available in service workers):
function getFavouritesFromStorage() {
    var str = localStorage.getItem("localData");
    if (str != null) { systemsObjArr = JSON.parse(str); }
}

// NEW (chrome.storage.local — asynchronous, works everywhere):
async function getFavouritesFromStorage() {
    const result = await chrome.storage.local.get("localData");
    if (result.localData != null) { systemsObjArr = JSON.parse(result.localData); }
}
```

**Best practice note**: Per [Chrome's storage API docs](https://developer.chrome.com/docs/extensions/reference/api/storage), `chrome.storage.local` data persists across service worker restarts and browser sessions. It is the correct replacement for localStorage in extensions.

---

## Step 3: Create `popup.js` — Popup/Options Page UI

Extract all DOM-related code from `background.js`:

- **`initateCode()`** (lines 85-125) — becomes `async`
- **Table functions**: `onTableChange()` (878), `addNewTableRow()` (883), `populateTable()` (890), `formatOneFreeRow()` (916)
- **`save_options()`** (lines 947-988) — migrate `localStorage.setItem` → `chrome.storage.local.set()`. After saving, send `chrome.runtime.sendMessage({type: "favourites-updated"})` to notify the service worker.
- **`requestNotificationPermission()`** (lines 1322-1361) — uses web Notification API + DOM, both available in popup context
- **`DeleteData()`** (lines 943-945) — migrate `localStorage.clear()` → `chrome.storage.local.remove("localData")`
- **DOMContentLoaded trigger** replaces `readystatechange` listener (lines 76-83)
- **Local `systemsTable`** variable via `document.getElementById("systemsTable")`

### One-time data migration for existing users:
Per [Google's official guidance](https://developer.chrome.com/docs/extensions/develop/migrate/to-service-workers), the recommended approach for migrating existing localStorage data is to use an offscreen document or handle it in a page context. Since our `About.html` popup opens on install/update (via `chrome.runtime.onInstalled`), we can migrate in `popup.js`:

```javascript
async function migrateFromLocalStorage() {
    const existing = localStorage.getItem("localData");
    if (existing) {
        await chrome.storage.local.set({ "localData": existing });
        localStorage.removeItem("localData");
    }
}
// Call at start of initateCode()
```

---

## Step 4: Rewrite `background.js` — Service Worker

### 4a: Import shared code
```javascript
importScripts('shared.js');
```
Per [Chrome's service worker basics docs](https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/basics), `importScripts()` must be called synchronously at the top level.

### 4b: Remove all DOM code (moved to popup.js)
- Lines 76-83: `document.addEventListener('readystatechange', ...)`
- Lines 85-125: `initateCode()`
- Lines 877-931: Table functions
- Lines 947-988: `save_options()`
- Lines 1322-1361: `requestNotificationPermission()`

### 4c: Remove the guard variable pattern
Delete lines 144-147 (`try { avoidDuplicateListernersDefined }` / `catch`). Register all event listeners unconditionally at the **top level** of the service worker.

**Best practice note**: Per [Chrome's docs](https://developer.chrome.com/docs/extensions/develop/migrate/to-service-workers), event listeners MUST be registered synchronously at the top level. "Registering a listener asynchronously is not guaranteed to work in Manifest V3" because the service worker reinitializes when events fire.

### 4d: Remove shared code (now in shared.js)
Delete all functions that moved to `shared.js`.

### 4e: Service worker initialization
```javascript
async function initServiceWorker() {
    await getFavouritesFromStorage();
    await updateContextMenu(undefined, "On Service Worker Start");
}
initServiceWorker();
```

### 4f: Migrate `chrome.tabs.executeScript()` → `chrome.scripting.executeScript()`

Two call sites (lines 1008, 1031). Per [Chrome's scripting API docs](https://developer.chrome.com/docs/extensions/reference/api/scripting):

```javascript
// OLD (MV2 — string code injection, removed in MV3):
const code = 'document.querySelector("head").innerHTML.includes("Nimblex")';
chrome.tabs.executeScript(currentTab.id, { code }, function(result) { ... });

// NEW (MV3 — function injection, async):
try {
    const results = await chrome.scripting.executeScript({
        target: { tabId: currentTab.id },
        func: () => document.querySelector("head").innerHTML.includes("Nimblex")
    });
    var isNimblex = results && results[0] && results[0].result === true;
} catch (error) {
    var isNimblex = false;
}
```

Key differences per [Chrome's API migration guide](https://developer.chrome.com/docs/extensions/develop/migrate/api-calls):
- `tabId` moves into `target` object
- `code` string replaced by `func` (function reference)
- Results wrapped: `results[0].result` instead of `result[0]`
- Promise-based (use `await`)
- Requires `"scripting"` permission

### 4g: Migrate `new Notification()` → `chrome.notifications.create()`

The web Notification API is **not available** in service workers. Per [Chrome's notifications guide](https://developer.chrome.com/docs/extensions/mv3/richNotifications/), use `chrome.notifications.create()` instead.

4 locations in background.js must change:
1. Line 380 — Add-To-Favourites notification
2. Line 688 — EForm name not found notification
3. Line 1372 — Offer cluster login notification
4. Line 1420 — Redirect after cluster login notification

```javascript
// OLD (web Notification API — not available in service workers):
var notifObj = new Notification("Title", { icon: ..., body: "..." });
notifObj.onclick = function() { ... };

// NEW (chrome.notifications API):
const notifId = "add-fav-" + Date.now();
chrome.notifications.create(notifId, {
    type: "basic",
    iconUrl: "icons/icon-ex-48.png",
    title: "Title",
    message: "body text here"
});
```

Add a single top-level `chrome.notifications.onClicked` listener to handle all notification clicks. Use a `pendingNotificationActions` map to track what each notification should do on click.

### 4h: Migrate `closeOldNotifications()` (lines 1306-1320)
Track notification IDs (strings) instead of Notification objects. Use `chrome.notifications.clear(notifId)` instead of `.close()`.

### 4i: Remove `Notification.permission` checks
Line 1114 uses `Notification.permission` — not available in service workers. The `"notifications"` manifest permission grants access automatically. Remove the `isAllowNotificationVisible` logic and the "Turn on useful notifications" context menu item.

### 4j: Migrate `getParams()` (lines 649-660)
Replace `document.createElement('a')` with `new URL()`. Note: this function appears unused in the codebase — consider removing entirely.

### 4k: Handle `favourites-updated` message from popup
```javascript
// Inside chrome.runtime.onMessage listener:
if (message && message.type === "favourites-updated") {
    await getFavouritesFromStorage();
    await updateContextMenu(undefined, "On Saved Favourites from Popup");
    return;
}
```

### 4l: Async cascade
Functions that must become `async`:
- `processCommand()` — calls `getFavouritesFromStorage()`, `openInNewDomain_checkIfNimblex()`
- `updateContextMenu()` — calls `chrome.scripting.executeScript()`
- `updateContextMenuNested()` — calls `countOfValidFavourites()`
- `openInNewDomain_checkIfNimblex()` — calls `chrome.scripting.executeScript()`

### 4m: Service worker dormancy — state persistence
Per [Chrome's docs](https://developer.chrome.com/docs/extensions/develop/migrate/to-service-workers), service workers terminate when inactive and all global variables are lost.

| Variable | Persistence Strategy |
|----------|---------------------|
| `systemsObjArr` | Already in `chrome.storage.local`; restored via `initServiceWorker()` on wake |
| `systemsVisitedStrArr` | Use `chrome.storage.session` (per-browser-session, survives SW restarts) |
| `arrayOfNotifications` | Track as notification ID strings; use `chrome.notifications.getAll()` if needed |
| `pendingNotificationActions` | Use `chrome.storage.session` |

---

## Step 5: Update `About.html`

Change script tags (lines 220-221):
```html
<!-- OLD: -->
<script type="text/javascript" src="about.js"></script>
<script type="text/javascript" src="background.js"></script>

<!-- NEW: -->
<script type="text/javascript" src="shared.js"></script>
<script type="text/javascript" src="popup.js"></script>
```

---

## Step 6: Delete `about.js`

The `avoidDuplicateListernersDefined` guard variable is no longer needed since the service worker is never loaded in the popup page.

---

## Feature Risk Assessment

Each feature is assessed for migration risk — how likely it is to break during migration and require debugging.

### LOW RISK (0-15% chance of issues)

| Feature | Risk | Reasoning |
|---------|------|-----------|
| **Keyboard shortcuts** (Alt+N/R/C/L) | 5% | `chrome.commands.onCommand` API is unchanged in MV3. The listener just needs to be top-level. |
| **Extension popup** (About.html display) | 10% | HTML/CSS unchanged. Just swapping script tags. Minor risk from async `initateCode()`. |
| **Extension icon and metadata** | 5% | Icons are unchanged. `action` replaces `browser_action` — straightforward rename. |
| **Open on install** (`chrome.runtime.onInstalled`) | 5% | API unchanged in MV3. |
| **URL parsing functions** (getInstanceUrl, getFormName, etc.) | 5% | Pure JavaScript logic, no API dependencies. Moving to shared.js is a copy-paste. |
| **Usage logging** (`logRequestInNimblex` via `fetch()`) | 5% | `fetch()` works in service workers. No changes needed. |

### MEDIUM RISK (15-40% chance of issues)

| Feature | Risk | Reasoning |
|---------|------|-----------|
| **Favorites management** (save/load/edit in popup) | 25% | The `localStorage` → `chrome.storage.local` migration introduces async patterns. Every call to `getFavouritesFromStorage()` must be awaited. 8 call sites must be updated. Missing a single `await` = favorites appear empty. |
| **Context menu** (right-click menu with dynamic items) | 30% | `chrome.contextMenus` API is unchanged, BUT `updateContextMenu()` becomes async (depends on `chrome.scripting.executeScript` and `countOfValidFavourites`). The async cascade through `updateContextMenuNested()` is complex. Risk of menus showing stale or incomplete data. |
| **Nimblex site detection** (`chrome.scripting.executeScript`) | 35% | Complete API replacement from `chrome.tabs.executeScript` to `chrome.scripting.executeScript`. Different parameter structure, different return value format. Must handle permissions errors for restricted pages. |
| **Favorites data migration** (localStorage → chrome.storage for upgrading users) | 30% | One-time migration runs in popup.js on first open after upgrade. Risk: user may not open popup immediately, leaving favorites appearing empty until they do. Also, the `onInstalled` handler opens About.html, but if user closes it before scripts load, migration may not complete. |
| **Open in favourite system** (navigate to same form on different server) | 20% | Core logic unchanged, but depends on both Nimblex site detection (async) and favorites loading (async). The async chain must be correct end-to-end. |

### HIGH RISK (40-70% chance of issues)

| Feature | Risk | Reasoning |
|---------|------|-----------|
| **Desktop notifications** (4 notification types) | 55% | Complete rewrite from web `Notification` API to `chrome.notifications.create()`. Different API surface, different click handling model (per-object `.onclick` → single global `onClicked` listener), different lifecycle management. Must map notification IDs to actions. The `closeOldNotifications()` function needs full rework. |
| **Cluster login with redirect** (`openClusterLoginWithRedirect`) | 50% | This function (lines 770-839) adds a nested `chrome.tabs.onUpdated` listener that waits for user to complete login, then redirects. In MV3, if the service worker goes dormant while waiting (user takes >30s to log in), the listener is lost and the redirect never happens. Requires careful handling with `chrome.storage.session` or acceptance of this edge case. |
| **Service worker dormancy** (state surviving sleep cycles) | 45% | All global variables (`systemsVisitedStrArr`, `arrayOfNotifications`, `pendingNotificationActions`) are lost when the service worker sleeps. Must persist to `chrome.storage.session` and restore on wake. Every write must be followed by a save. Easy to miss a location. |
| **Notification permission flow** ("Turn on useful notifications" button) | 40% | The `Notification.permission` check doesn't exist in service workers. The context menu item `enable-notifications` and the popup button both need rethinking. The manifest `"notifications"` permission means the extension always has permission in MV3, making this flow potentially unnecessary — but removing it changes the UX. |

### CRITICAL RISK (70%+ chance of needing significant debugging)

| Feature | Risk | Reasoning |
|---------|------|-----------|
| **Async cascade** (making 6+ functions async) | 70% | The ripple effect of making `getFavouritesFromStorage()` async touches nearly every major function. `processCommand()`, `updateContextMenu()`, `updateContextMenuNested()`, `openInNewDomain_checkIfNimblex()`, `save_options()`, `populateTable()`, `initateCode()`, and `countOfValidFavourites()` all become async. Missing a single `await` creates a subtle race condition. This is the #1 risk area. |
| **Hybrid file splitting** (background.js → 3 files) | 65% | The 1434-line background.js must be surgically split into `shared.js`, `popup.js`, and a rewritten `background.js`. Functions reference each other across these boundaries. Getting the boundaries wrong (e.g., missing a shared dependency) causes undefined function errors. The `importScripts` call in the service worker must load before any function calls. |

---

## Risk Mitigation Strategy

1. **Test incrementally**: Load the extension after each major step, not just at the end
2. **Async cascade**: Write a checklist of every function that becomes async and every call site — verify each one
3. **Service worker dormancy**: Test by using the extension, waiting 2+ minutes, then using it again
4. **Notifications**: Test each of the 4 notification types individually
5. **Cluster login redirect**: Test with both fast (<5s) and slow (>60s) login scenarios
6. **Favorites migration**: Test with existing localStorage data and with fresh install

---

## Verification Plan

1. Load as unpacked extension in Chrome (`chrome://extensions` → Developer mode → Load unpacked)
2. Check for errors in the service worker console (click "service worker" link on extensions page)
3. **Popup**: Click extension icon → About.html displays correctly with favorites table
4. **Favorites**: Add/edit/remove favorites → persist across browser restart
5. **Context menu on Nimblex site**: Right-click → full menu (New Record, Tabular Report, Designer, etc.)
6. **Context menu on non-Nimblex site**: Right-click → only Quick Favourites or minimal menu
7. **Keyboard shortcuts**: Alt+N, Alt+R, Alt+C, Alt+L → correct pages open
8. **Notifications**: Navigate to Nimblex login page → cluster login notification appears
9. **Add to Favourites**: Right-click → Add to Favourites → notification + persistence
10. **Favourite navigation**: Right-click → My Favourites → select system → correct navigation
11. **Service worker dormancy**: Use extension, wait 2+ minutes idle, use again → everything works
12. **Upgrade path**: Test with existing localStorage data → verify one-time migration works

---

## Sources

- [Manifest V3 Migration Overview](https://developer.chrome.com/docs/extensions/develop/migrate)
- [Migrate to a Service Worker](https://developer.chrome.com/docs/extensions/develop/migrate/to-service-workers)
- [MV3 Migration Checklist](https://developer.chrome.com/docs/extensions/develop/migrate/checklist)
- [Update API Calls (tabs.executeScript → scripting.executeScript)](https://developer.chrome.com/docs/extensions/develop/migrate/api-calls)
- [chrome.scripting API Reference](https://developer.chrome.com/docs/extensions/reference/api/scripting)
- [chrome.storage API Reference](https://developer.chrome.com/docs/extensions/reference/api/storage)
- [chrome.notifications API (Rich Notifications)](https://developer.chrome.com/docs/extensions/mv3/richNotifications/)
- [Service Worker Basics](https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/basics)
- [MV2 Deprecation Timeline](https://developer.chrome.com/docs/extensions/develop/migrate/mv2-deprecation-timeline)

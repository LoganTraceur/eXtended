/* 
This code is injected into all new tabs so that it calls the update right click listener just before a right click
*/

// ------------------------------- Send the message back to the background.js -----------------------------
function rightClickEventHandler() {
	//alert("File worked");  
	console.log("Right Click Detected");
	//console.log(e);
	
	// SendMessage 1/3. Send the background a message requesting the user's data
	chrome.runtime.sendMessage('eXtendedRightClickRefresh', (response) => {
		// 3. Got an asynchronous response with the data from the background
		//console.log('received user data', response);
		//initializeUI(response);
	});
}

// -------------------------------------------- Attach Listener -----------------------------------------
// Method 1: On Context menu, But not before :(
// document.addEventListener("contextmenu", rightClickEventHandler);	// This is the simpliest but triggers to fast and the context menu does not refresh in time before it is loaded.

// Method 2: Before right click
window.addEventListener("mousedown", onClick);							// This is good but it doesnt take into account the "Context" (rightclick) keyboard button
function onClick(e) {
    if (!e)
    {
        return;
    }

    switch(`${e.which}${e.button}`)
    {
        case '32':	rightClickEventHandler();        											break;
		//case '32':  console.log('Right mouse button ' + e.clientX + 'x' + e.clientY); 		break;
		//case '10':  console.log('Left mouse button at ' + e.clientX + 'x' + e.clientY); 		break;
        //case '21':  console.log('Middle mouse button ' + e.clientX + 'x' + e.clientY);     	break;
        //case '43':  console.log('Backward mouse button ' + e.clientX + 'x' + e.clientY);    	break;
        //case '54':  console.log('Forward mouse button ' + e.clientX + 'x' + e.clientY);     	break;
    }
}
